import java.util.ArrayList;
/**
 * Class that represents a vertex or node in the graph
 * @author María Sofía Uribe
 * @author Isabel Graciano
 */
public class Node {
    /** identifier of the node*/
    int idNode;
    /** X Coordinate of the node*/
    private double coordx;
    /** Y Coordinate of the node*/
    private double Coordy;
    /** Name of the location represented by the node*/
    private final String name;
    ArrayList<Node> Route;
    boolean isRideSharing;

    /**
     * Constructs a vertex or node in the graph given an ID , x coordinate, y coordinate and a name of the location
     * @param idNode identifier of the node
     * @param Coordx x Coordinate of the node (Decimal longitude )
     * @param Coordy y Coordinate of the node (Decimal latitude)
     * @param name Name of the location represented by the node
     */
    public Node(int idNode,  double Coordx, double Coordy, String name) {
        this.idNode = idNode;
        this.coordx = Coordx;
        this.Coordy = Coordy;
        this.name = name;
        this.Route = new ArrayList<>();
        this.isRideSharing = false;
    }

    /** Returns the id of this node
     * @return id of this node
     * */
    public int getID() {
        return idNode;
    }

    /** Returns the x Coordinate of the node (Decimal longitude ) of this node
     * @return Decimal longitude of the node
     * */
    public double getCoordx() {
        return coordx;
    }

    /** Returns the y Coordinate of the node (Decimal longitude ) of this node
     * @return Decimal latitude of the node
     * */
    public double getCoordy() {
        return Coordy;
    }

    /** Returns the list of nodes this Node picks up to get to first node of a graph
     * @return list of nodes this Node picks up
     * */
    public ArrayList<Node> getRoute() {
        return Route;
    }

    /** adds a node to the list of passengers in this Node's route
     * @param p node to be added
     * */
    public void addCartoRoute(Node p) {

        this.Route.add(p);
        p.setIsRideSharing(true);
    }

    /** Returns a boolean that determines whether the current car is sharing a car with others
     * @return true if the current car is sharing a car with others, false otherwise
     * */
    public boolean isRideSharing() {
        return isRideSharing;
    }

    /** Assigns a boolean to the field isRideSharing that determines whether the current car is sharing a car with others
     * @param isRideSharing boolean that determines whether the current car is sharing a car with others
     * */
    public void setIsRideSharing(boolean isRideSharing) {
        this.isRideSharing = isRideSharing;
    }

    /** Returns the number of nodes in this Node's route
     * @return number of nodes in this Node's route
     * */
    public int getNumberPassengers() {
        return Route.size();
    }

    /** Returns the time that it takes this Node to get to the goal (node 1) in a given graph
     * @param matrix given graph
     * @return time that it takes this Node to get to the goal (node 1)
     * */
    public double getTimeToGoal(Edge [][] matrix){
        return matrix[getID() - 1][0].getCostMinutes();
    }
    /** Returns the time that it takes this Node to get to a given node in a given graph
     * @param matrix given graph
     * @param j given target goal
     * @return time that it takes this Node to get to the goal (node 1)
     * */
    public double getTimeToNode(Edge [][] matrix, Node j ){
        return matrix[getID() - 1][j.getID() -1].getCostMinutes();
    }

    /** Returns the sum of time that it takes this Node to get to a given node plus
     * and the time it takes to go from that given node to the node 1 in a given graph
     * @param matrix given graph
     * @param j given target goal
     * @return total time it takes from this node to node 1 passing through node j
     * */
    public double getFval(Edge [][] matrix, Node j){
        return  j.getTimeToGoal(matrix)+ getTimeToNode(matrix,j);
    }

    /** Returns an array of edges in ascending order according to the time that it takes to go from each node to node 1
     * @param matrix given graph
     * @return array of edges sorted by the time that it takes to go from each node to node 1
     * */
    public Edge [] getTimes(Edge [][] matrix){
        Edge [] distanceInOrder = new Edge[matrix.length-1];
        int k =0;
        int nodeid = getID() -1;
        for (int i =0 ; i< matrix.length;i++){
            if (i != (nodeid)){
                distanceInOrder[k] = matrix[nodeid][i];
                k++;
            }
        }
        quickSortTime(distanceInOrder,0,distanceInOrder.length-1);
        return distanceInOrder;
    }


    /**
     * Method that implements the MergeSort algorithm of a set of Edge elements in descending order according to ther cost in time
     * @param a an array with Edge elements.
     * @param l = left index
     * @param r = right index
     */
    public static void quickSortTime(Edge a[], int l, int r) {
        if (l < r) {
            int index = findIndexTime(a, l, r);
            quickSortTime(a,l, index-1);
            quickSortTime(a,index+1, r);
        }
    }

    /** Method that takes the last element as an index and changes all elements with less time to a position before this element
     and positions elements with greater time elements after that index
     * @param arr un arreglo de elementos
     * @param l The initial index of the subset that you want to partition
     * @param r final index of the subset you want to partition
     * @return the index where the set of numbers is split
     */
    private static int findIndexTime(Edge arr[], int l, int r ) {

        Double index = arr[r].getCostMinutes() ;
        int i = l-1;
        for (int j = l; j < r; j++) {
            if (arr[j].getCostMinutes() <= index) {
                i++;
                Edge temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        Edge temp = arr[i+1];
        arr[i+1] = arr[r];
        arr[r] = temp;
        return i+1;
    }





}
