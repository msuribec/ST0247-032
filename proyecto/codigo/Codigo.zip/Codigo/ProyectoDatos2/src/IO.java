

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.io.PrintWriter;
import java.util.ArrayList;

public class IO {


    public void readGraph(int N, double condition, boolean usingConstant){
        String filename;
        String fileOUT;
        if (usingConstant){
            filename =  "dataset-ejemplo-U="+N+"-p=1.2.txt";
            fileOUT = "respuesta-ejemplo-U="+N+"-c="+condition+".txt";
            readGraph(N,condition,true,filename,fileOUT);
        }else {
            filename = "dataset-ejemplo-U="+N+"-p="+condition+".txt";
            fileOUT = "respuesta-ejemplo-U="+N+"-p="+condition+".txt";
            readGraph(N,condition,false,filename,fileOUT);
        }


    }


    private void readGraph(int N, double condition, boolean usingConstant, String filename, String fileOUT){
        long beforeUsedMem= Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
        long startTime = 0;
        long endTime=0;
        ArrayList<Node> cars = new ArrayList<>();//  starts at 0 to 204
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            String lineaActual = br.readLine();
            String [] cadenaParticionada;
            for (int i = 1; i <= 3; i++)lineaActual = br.readLine();

            for (int i = 0; i < N ; i++){
                lineaActual = br.readLine();
                String name= "";
                cadenaParticionada = lineaActual.split(" ");
                if ((cadenaParticionada.length >= 4)) {
                    for (int j=3; j<cadenaParticionada.length;j++)
                        name += " "+cadenaParticionada[j];
                }

                int id =Integer.parseInt(cadenaParticionada[0]);
                double x = Double.parseDouble(cadenaParticionada[1]);
                double y = Double.parseDouble(cadenaParticionada[2]);
                cars.add(new Node(id,x,y,name));
            }
            for (int i = 0; i <= 3; i++)
                lineaActual = br.readLine();

            Edge [][] paths = new Edge [N][N];
            while (lineaActual != null){
                cadenaParticionada = lineaActual.split(" ");
                int id1 = Integer.parseInt(cadenaParticionada[0]) - 1;
                int id2 = Integer.parseInt(cadenaParticionada[1])- 1;
                Double cost = Double.parseDouble(cadenaParticionada[2]);
                paths[id1][id2] = new Edge(cost,cars.get(id1),cars.get(id2));
                lineaActual = br.readLine();
            }


            br.close();
            startTime=System.currentTimeMillis();
            Edge [] edges = new Graph().Solve(paths,condition, usingConstant);
            endTime = System.currentTimeMillis();

            try {
                PrintWriter escritor = new PrintWriter(fileOUT, "UTF-8");
                int numberCars = 0;
                for (Edge e : edges){
                    Node node = e.getSrc();
                    if (node != null  && node.getRoute().size()> 0){
                        numberCars++;
                        ArrayList<Node> nodes = node.getRoute();
                        for (int i = 0 ; i< nodes.size() ; i++){
                            Node n = nodes.get(i);
                            if (i != nodes.size() -1) escritor.print(n.getID() + ",");
                            else escritor.println(n.getID());
                        }

                    }
                }
                System.out.println("n: " + numberCars);
                escritor.close();
            }
            catch(IOException ioe) {
                System.out.println("Error escribiendo el archivo de salida " + ioe.getMessage() );
            }

        } catch(IOException e) {
            System.out.println( e.getMessage());
        }

        long timeElapsed = endTime - startTime;
        System.out.println("Execution time in milliseconds: " + timeElapsed);

        long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
        long actualMemUsed=afterUsedMem-beforeUsedMem;
        System.out.println("Memory used " + actualMemUsed + "mb");

    }



    public static void main (String [] args){
        IO test  = new IO();
        test.readGraph(205,1.3,false);
//        test.readGraph(205,6.1,true);

    }

}
