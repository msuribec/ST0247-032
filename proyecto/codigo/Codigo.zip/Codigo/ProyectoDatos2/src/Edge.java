/**
 * Class that represents an edge or arc in the graph
 * @author María Sofía Uribe
 * @author Isabel Graciano
 */
public class Edge {
    /** Source node*/
    private Node src;
    /** Destination node*/
    private Node destination;
    /** Time it takes to go from the source node to the destination node*/
    private Double costMinutes;
    private Double distanceMeters;

    /** Constructs the edge from the source node to the destination with a given node weight
     * @param src destination node
     * @param destination destination node
     *@param costMinutes cost (in minutes) of the edge
     * */
    public Edge(double costMinutes, Node src, Node destination) {
        this.src = src;
        this.destination = destination;
        this.costMinutes = costMinutes;
        this.distanceMeters = CalcDistance(src,destination);
    }

    /** Returns the distance in kilometers between the physical locations of two nodes given(Given in decimal latitude and longitude)
     *
     * @return the distance in kilometers between the two nodes given
     * */
    public Double getDistanceKM() {
        return distanceMeters;
    }

    /** Returns the time it takes to go from the source node to the destination node
     * @return time it takes to go from the source node to the destination node
     * */
    public Double getCostMinutes() { return costMinutes; }


    /** Returns the source node of this edge
     * @return the source node of this edge
     * */
    public Node getSrc() {
        return src;
    }

    /** Returns the destination node of this edge
     * @return the destination node of this edge
     * */
    public Node getDestination() {
        return destination;
    }

    /** Returns the distance in kilometers between the physical locations of two nodes given(Given in decimal latitude and longitude)
     * This method uses the Haversine Formula which is recommended by CALTECH for these tipe of calculations (it ignores the ellipsoidal shape)4
     * @see <a href="https://www.movable-type.co.uk/scripts/latlong.html" >Haversine formuula explanation</a>
     * The radius of the earth assumed was 6377.889 km which is the radius of the earth at latitude 6.2269508 and Height of 1.495 m above see level
     * (which is the location of Medellin, Colombia where this program was developed)
     * @see <a href="https://rechneronline.de/earth-radius/">Earth Radius by Latitude Calculator</a>
     * Latitudes and longitudes are assumed to be in decimal degrees
     * @param node1 first given node
     * @param node2 second given node
     * @return the distance in kilometers between the two nodes given
     * */
    public double CalcDistance(Node node1,Node node2){
        double lat1 = node1.getCoordy();
        double lon1 = node1.getCoordx();
        double lat2 = node2.getCoordy();
        double lon2 =  node2.getCoordx();
        double latd = toRad(lat2-lat1);
        double lond = toRad(lon2-lon1);
        double a = Math.sin(latd / 2) * Math.sin(latd / 2) +
                Math.cos(toRad(lat1)) *
                        Math.cos(toRad(lat2)) *
                        Math.sin(lond / 2) * Math.sin(lond/ 2);
        double R = 6377.889;

        return  R* 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }

    /** Converts an angle in degrees to radians
     * @param value angle in degrees
     * @return the given angle in radians
     * */
    private static Double toRad(Double value) {

        return value * Math.PI / 180;
    }


}
