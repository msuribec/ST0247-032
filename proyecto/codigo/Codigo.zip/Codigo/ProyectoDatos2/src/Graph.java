
import java.util.ArrayList;


/**
 * Class that represents the graph and determines which nodes will share a ride
 * @author María Sofía Uribe
 * @author Isabel Graciano
 */

public class Graph {
    /** Matrix that stores the edges between nodes , an edge connecting the nodes i and j will be stored in the position [i-1][j-1]*/
    private Edge[][] matrix;
    /** Boolean that determines whether the solution takes into account the value p (false) or a value c(true)
     * @see IO for more information on the difference between P and C*/
    private boolean isUsingC;

    /** decimal that holds the value of the condition
     * @see IO for more information on this condition and the difference between P and C*/
    private double condition;

    /** Auxiliary method that assigns the nodes to each route by calling the DirectedSearchMethod for each edge of the given graph ,
     * starting with the edge with the biggest distance
     * @param Matrix given graph
     * @param condition constraint given
     * @param usingConstant Boolean that determines whether the solution takes into account the value p (false) or a value c(true)
     * @return Array of edges , where all of the routes have been assigned */
    public Edge[] Solve(Edge[][] Matrix, double condition, boolean usingConstant) {
        this.matrix = Matrix;
        this.isUsingC = usingConstant;
        this.condition = condition;
        Edge[] distances = distances();
        for (Edge e : distances) DirectedSearch(e.getSrc());
        return distances;
    }


    /** Method that assigns cars to each route if they do not violate the condition estsblished and the route has available seats.
     * @param MainCar Node that will pick up other nodes on its way to node 1*/
    public void DirectedSearch(Node MainCar) {
        ArrayList<Double> costsToEnd = new ArrayList<>();
        if (!MainCar.isRideSharing()) {
            Node currentCar = MainCar;
            MainCar.addCartoRoute(MainCar);
            AddCond(MainCar,costsToEnd);
            int limit = 0 ;
            outerloop: while (limit < matrix.length-1 && MainCar.getNumberPassengers()<5) {
                Edge[] Route = currentCar.getTimes(matrix);
                Node nextCar = Route[limit].getDestination();
                limit++;
                if (nextCar != null && !nextCar.isRideSharing()) {
                    for (int i =0 ; i < costsToEnd.size() ; i++)
                        if (currentCar.getFval(matrix,nextCar)>= costsToEnd.get(i) ) continue outerloop;
                    MainCar.addCartoRoute(nextCar);
                    for (int i = 0; i < costsToEnd.size(); i++) {
                        double cost = costsToEnd.get(i);
                        cost -= currentCar.getTimeToNode(matrix,nextCar);
                        costsToEnd.set(i, cost);
                    }
                    limit = 0;
                    AddCond(nextCar,costsToEnd);
                    currentCar = nextCar;
                }
            }
        }
    }


    /** Method that adds the time that it takes to node n to reach node 1 to the list
     * of costs depending on the constant that is being used (p or c)
     * @param n Node that will pick up other nodes on its way to node 1
     * @param costsToEnd list of times (in minutes) to node 1
     * @see IO for more information on the difference between P and C*/
    public void AddCond(Node n, ArrayList<Double> costsToEnd){
        double dist = n.getTimeToGoal(matrix);
        if (isUsingC) costsToEnd.add(condition + dist);
        else costsToEnd.add(dist * condition);

    }

    /** Returns an array of edges in descending order according to the distances that it takes to go from each node to node 1
     * @return array of edges sorted by the distances that it takes to go from each node to node 1
     * */
    public Edge [] distances(){
        Edge [] dist = new Edge[matrix.length - 1];
        //ignore distance form 1 to 1 (it is always 0 for this problem)
        for (int i = 1 ; i< matrix.length ; i++) dist[i-1]= matrix[i][0];
        quickSortDist(dist,0,dist.length-1);
        return dist;
    }




    /**
     * Method that implements the MergeSort algorithm of a set of Edge elements in descending order according to ther cost in time
     * @param a an array with Edge elements.
     * @param l = left index
     * @param r = right index
     *
     */
    public static void quickSortDist(Edge a[], int l, int r) {
        if (l < r) {
            int index = findIndexDist(a, l, r);
            quickSortDist(a,l, index-1);
            quickSortDist(a,index+1, r);
        }
    }

    /** Method that takes the last element as an index and changes all elements with greater time to a position before this element
     and positions elements with less time elements after that index
     * @param arr un arreglo de elementos
     * @param l The initial index of the subset that you want to partition
     * @param r final index of the subset you want to partition
     * @return the index where the set of numbers is split
     */
    private static int findIndexDist(Edge arr[], int l, int r ) {

        Double index = arr[r].getDistanceKM();
        int i = l-1;
        for (int j = l; j < r; j++) {
            if (arr[j].getDistanceKM() >= index) {
                i++;
                Edge temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        Edge temp = arr[i+1];
        arr[i+1] = arr[r];
        arr[r] = temp;

        return i+1;
    }













}
