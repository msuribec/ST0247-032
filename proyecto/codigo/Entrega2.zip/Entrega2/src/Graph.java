import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

/**
 * Class that creates the graph , determines which nodes will share a ride and prints the answer.
 * @author María Sofía Uribe
 * @author Isabel Graciano
 */
public class Graph {

    /** number of nodes of the graph*/
    int V;
    /** Hashmap that has an integer as a key and Nodes as a value*/
    private HashMap<Integer,Node> Map = new HashMap<>();

    /** Constructs a graph
     * @param v number of nodes in the graph*/
    public Graph(int v) {
        V = v;
    }
    /** adds the destination node as successor to the source node
     * @param source id of the source node
     * @param destination id of the destination node
     * @param weight of the edge that connects the source node and the destination node*/
    public void addSuccesor (int source, int destination, double weight){
        Node dest = Map.get(destination);
        Edge e = new Edge(dest,weight);
        Node src = Map.get(source);
        src.EdgestoVisit.add(e);
    }

    /** changes the h value of a given vertex
     * @param idnode id of the node
     * @param h h value of the node*/
    public void addHval(int idnode, double h){
        Map.get(idnode).hval = h;
    }

    /** Adds a node to the graph
     * @param iden identifier of the node
     * @param x  x Coordinate of the node
     * @param y  y Coordinate of the node
     * @param name Name of the location represented by the node*/
    public void addNode(int iden, double x,  double y,String name){
        Map.put(iden,new Node(iden,x,y,name));
    }

    /** Adds a node to the graph
     * @param iden identifier of the node
     * @param x  x Coordinate of the node
     * @param y  y Coordinate of the node
     * @param name Name of the location represented by the node
     * @param h h value of the node*/
    public void addNode(int iden, double x,  double y,String name,double h){
        Map.put(iden,new Node(iden,x,y,name,h));
    }

    /** Gets the weight of the edge that connects two nodes
     * @param source id of the source node
     * @param destination id of the destination node
     * @return weight of the edge that connects two nodes*/
    public double getMinCost(int source, int destination){
        Node src = Map.get(source);
        for (Edge e : src.EdgestoVisit){
            if (e.NodeDest.idNode == destination){
                return e.cost;
            }
        }
        return -1;
    }



    /**
     * resets the parent, f value and g value of every node in a map
     */
    public void reset() {
        Iterator it = Map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry element = (Map.Entry) it.next();
            Map.get(element .getKey()).reset();
        }

    }

    /**
     * Determines which nodes will share a ride and prints the answer.
     * @param condition condition to compute the maximum value an owner can excede their cost to reach vertex 1
     */
    public void solve(double condition){
        List<List<Integer>> resp= new LinkedList<>();

        for (int i = 1; i <= V; i++) resp.add(new LinkedList<>());

        for (int i = V; i >= 2; i--){
            Node ni = Map.get(i);
            Node n1 = Map.get(1);
            if (!ni.isRideSharing){
                DirectedSearch.Search(ni,n1,false);
                List<Integer> path = DirectedSearch.recoverPath(n1);
                resp.add(new ArrayList<>());
                for (Integer a: path) {
                    Node na = Map.get(a);
                    if (!na.isRideSharing){
                        resp.get(i).add(a);
                        na.isRideSharing = true;
                    }
                }
                System.out.println("Path from : "+ i +" to 1 " + path);
            }
            reset();
        }





        for (int i = 0; i < V -1 ; i++) {
            List<Integer> r1 = resp.get(i);
            List<Integer> r2 = resp.get(i+1);
            if (r1.size()== 1 && r2.size()==1 ) {
                int first = r1.get(0);
                int second = r1.get(0);
                double cost1 = getMinCost(first,second);
                double oldCost1 = Map.get(first).hval;

                double cost2 = getMinCost(second,first);
                double oldCost2 = Map.get(second).hval;

                if (cost1 < cost2 && oldCost1 + cost1 != ((condition)*(oldCost1)+oldCost1)){
                    r1.add(r2.get(0));
                    resp.set(i+1,new ArrayList<>());
                }

                if (cost2 <= cost1 && oldCost2 + cost2 != ((condition)*(oldCost2) +oldCost2)){
                    r2.add(r1.get(0));
                    resp.set(i,new ArrayList<>());
                }
            }
        }


        final String nombreDelArchivo = "respuesta-ejemplo-U="+V+"-p="+condition+".txt";
        try {
            PrintWriter escritor = new PrintWriter(nombreDelArchivo, "UTF-8");
            for (List<Integer> L: resp) {
                if (L.size() > 0){
                    for (Integer a: L )
                        if (a!=1) escritor.print(a+" ");
                    escritor.println();
                }
            }
            escritor.close();
        }
        catch(IOException ioe) {
            System.out.println("Error escribiendo el archivo de salida " + ioe.getMessage() );
        }


    }
}